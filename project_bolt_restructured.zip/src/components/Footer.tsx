import React from 'react';
import { Link } from 'react-router-dom';
import { Code2, Mail, Phone, MapPin } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-black/80 border-t border-purple-500/20 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="col-span-1 lg:col-span-2">
            <Link to="/" className="flex items-center space-x-2 mb-4">
              <Code2 className="h-8 w-8 text-purple-400" />
              <span className="text-xl font-bold text-white">Hot Beans Web</span>
            </Link>
            <p className="text-gray-300 mb-6 max-w-md">
              Leading web development recruitment agency connecting talented developers 
              with innovative companies. Build your future in tech with us.
            </p>
            <div className="space-y-2">
              <div className="flex items-center space-x-2 text-gray-300">
                <Mail className="h-4 w-4 text-purple-400" />
                <span>contact@hotbeansweb.com</span>
              </div>
              <div className="flex items-center space-x-2 text-gray-300">
                <Phone className="h-4 w-4 text-purple-400" />
                <span>+44 (0) 20 7123 4567</span>
              </div>
              <div className="flex items-center space-x-2 text-gray-300">
                <MapPin className="h-4 w-4 text-purple-400" />
                <span>London, United Kingdom</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-300 hover:text-purple-300 transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/trainees" className="text-gray-300 hover:text-purple-300 transition-colors">
                  Our Trainees
                </Link>
              </li>
              <li>
                <Link to="/jobs" className="text-gray-300 hover:text-purple-300 transition-colors">
                  Job Opportunities
                </Link>
              </li>
              <li>
                <Link to="/apply" className="text-gray-300 hover:text-purple-300 transition-colors">
                  Apply Now
                </Link>
              </li>
              <li>
                <Link to="/courses" className="text-gray-300 hover:text-purple-300 transition-colors">
                  Courses
                </Link>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Legal</h3>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-gray-300 hover:text-purple-300 transition-colors">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-purple-300 transition-colors">
                  Terms of Service
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-purple-300 transition-colors">
                  Contact Us
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-purple-300 transition-colors">
                  Careers
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-purple-500/20 mt-8 pt-8 text-center">
          <p className="text-gray-400">
            © {currentYear} Hot Beans Web. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;