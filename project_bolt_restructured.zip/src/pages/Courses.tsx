import React from 'react';
import { ExternalLink, Star, Clock, Users, BookOpen } from 'lucide-react';

const Courses: React.FC = () => {
  const courses = [
    {
      id: 1,
      title: "The Complete Web Developer Course",
      provider: "Udemy",
      image: "https://images.pexels.com/photos/270348/pexels-photo-270348.jpeg?auto=compress&cs=tinysrgb&w=400",
      description: "Master web development with HTML, CSS, JavaScript, React, Node.js, and more. Build real projects and get job-ready skills.",
      duration: "42 hours",
      students: "180,000+",
      rating: 4.6,
      price: "£89.99",
      features: [
        "HTML5, CSS3, and JavaScript fundamentals",
        "React and Redux for frontend development",
        "Node.js and Express for backend",
        "MongoDB database integration",
        "Real-world projects and portfolio pieces"
      ],
      url: "https://udemy.com"
    },
    {
      id: 2,
      title: "JavaScript Algorithms and Data Structures",
      provider: "freeCodeCamp",
      image: "https://images.pexels.com/photos/943096/pexels-photo-943096.jpeg?auto=compress&cs=tinysrgb&w=400",
      description: "Learn JavaScript fundamentals through interactive challenges and build algorithmic thinking skills essential for technical interviews.",
      duration: "300 hours",
      students: "400,000+",
      rating: 4.8,
      price: "Free",
      features: [
        "Interactive JavaScript challenges",
        "ES6+ modern JavaScript features",
        "Functional programming concepts",
        "Object-oriented programming",
        "Algorithm and data structure problems"
      ],
      url: "https://freecodecamp.org"
    },
    {
      id: 3,
      title: "React - The Complete Guide",
      provider: "Udemy",
      image: "https://images.pexels.com/photos/11035380/pexels-photo-11035380.jpeg?auto=compress&cs=tinysrgb&w=400",
      description: "Dive deep into React with hooks, context, Redux, and Next.js. Build complex applications with modern React patterns.",
      duration: "48 hours",
      students: "150,000+",
      rating: 4.7,
      price: "£94.99",
      features: [
        "React hooks and functional components",
        "State management with Context and Redux",
        "React Router for navigation",
        "Next.js for server-side rendering",
        "Testing React applications"
      ],
      url: "https://udemy.com"
    },
    {
      id: 4,
      title: "Node.js Developer Course",
      provider: "Udemy",
      image: "https://images.pexels.com/photos/1181472/pexels-photo-1181472.jpeg?auto=compress&cs=tinysrgb&w=400",
      description: "Build scalable backend applications with Node.js, Express, MongoDB, and deploy to production environments.",
      duration: "35 hours",
      students: "120,000+",
      rating: 4.5,
      price: "£79.99",
      features: [
        "Node.js runtime and npm ecosystem",
        "Express.js web framework",
        "MongoDB and Mongoose ODM",
        "RESTful API development",
        "Authentication and security"
      ],
      url: "https://udemy.com"
    },
    {
      id: 5,
      title: "Full Stack Open",
      provider: "University of Helsinki",
      image: "https://images.pexels.com/photos/1181298/pexels-photo-1181298.jpeg?auto=compress&cs=tinysrgb&w=400",
      description: "Deep dive into modern web development with React, Redux, Node.js, MongoDB, GraphQL and TypeScript.",
      duration: "200 hours",
      students: "50,000+",
      rating: 4.9,
      price: "Free",
      features: [
        "Modern JavaScript and TypeScript",
        "React with hooks and testing",
        "Node.js backend development",
        "GraphQL API development",
        "University-level curriculum"
      ],
      url: "https://fullstackopen.com"
    },
    {
      id: 6,
      title: "CSS Grid and Flexbox Course",
      provider: "CSS Grid",
      image: "https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=400",
      description: "Master modern CSS layout techniques with comprehensive Grid and Flexbox training from beginner to advanced.",
      duration: "25 hours",
      students: "80,000+",
      rating: 4.4,
      price: "£49.99",
      features: [
        "CSS Grid layout system",
        "Flexbox for responsive design",
        "Modern CSS properties",
        "Practical layout examples",
        "Browser compatibility techniques"
      ],
      url: "https://cssgrid.io"
    }
  ];

  const learningPaths = [
    {
      title: "Frontend Developer Path",
      description: "Master HTML, CSS, JavaScript, and React to become a frontend specialist",
      courses: ["HTML/CSS Fundamentals", "JavaScript Mastery", "React Complete Guide", "Advanced CSS"],
      duration: "6-8 months"
    },
    {
      title: "Backend Developer Path",
      description: "Learn server-side development with Node.js, databases, and API design",
      courses: ["JavaScript Basics", "Node.js Development", "Database Design", "API Development"],
      duration: "5-7 months"
    },
    {
      title: "Full Stack Developer Path",
      description: "Combine frontend and backend skills for complete web development mastery",
      courses: ["Frontend Essentials", "Backend Fundamentals", "Database Management", "DevOps Basics"],
      duration: "8-12 months"
    }
  ];

  return (
    <div className="pt-24 pb-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl sm:text-5xl font-bold text-white mb-6">
            Advance Your Skills with
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-purple-600">
              Top Web Development Courses
            </span>
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Curated selection of the best online courses to accelerate your web development journey. 
            From beginner-friendly to advanced topics, find the perfect course for your skill level.
          </p>
        </div>

        {/* Learning Paths */}
        <section className="mb-20">
          <h2 className="text-3xl font-bold text-white mb-8 text-center">Recommended Learning Paths</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {learningPaths.map((path, index) => (
              <div
                key={index}
                className="bg-gray-900/50 border border-purple-500/20 rounded-lg p-6 backdrop-blur-sm hover:bg-gray-900/70 hover:border-purple-500/40 transition-all duration-300"
              >
                <h3 className="text-xl font-bold text-white mb-3">{path.title}</h3>
                <p className="text-gray-300 mb-4">{path.description}</p>
                <div className="mb-4">
                  <div className="text-sm text-purple-300 mb-2">Estimated Duration: {path.duration}</div>
                  <div className="text-sm text-gray-400">Courses Include:</div>
                  <ul className="text-sm text-gray-300 mt-1">
                    {path.courses.map((course, courseIndex) => (
                      <li key={courseIndex} className="flex items-center space-x-2">
                        <div className="w-1 h-1 bg-purple-400 rounded-full"></div>
                        <span>{course}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Courses Grid */}
        <section>
          <h2 className="text-3xl font-bold text-white mb-8 text-center">Featured Courses</h2>
          <div className="grid lg:grid-cols-2 gap-8">
            {courses.map((course) => (
              <div
                key={course.id}
                className="bg-gray-900/50 border border-purple-500/20 rounded-lg overflow-hidden backdrop-blur-sm hover:bg-gray-900/70 hover:border-purple-500/40 transition-all duration-300 group"
              >
                {/* Course Image */}
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={course.image}
                    alt={course.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-purple-600/20 group-hover:bg-purple-600/10 transition-colors"></div>
                  <div className="absolute top-4 right-4 bg-black/70 text-white px-3 py-1 rounded-full text-sm font-medium">
                    {course.price}
                  </div>
                </div>

                {/* Course Content */}
                <div className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-purple-300 font-medium">{course.provider}</span>
                    <div className="flex items-center space-x-1">
                      <Star className="h-4 w-4 text-yellow-400 fill-current" />
                      <span className="text-gray-300 text-sm">{course.rating}</span>
                    </div>
                  </div>

                  <h3 className="text-xl font-bold text-white mb-3">{course.title}</h3>
                  <p className="text-gray-300 mb-4 leading-relaxed">{course.description}</p>

                  {/* Course Stats */}
                  <div className="flex items-center space-x-6 mb-4 text-sm text-gray-400">
                    <div className="flex items-center space-x-1">
                      <Clock className="h-4 w-4" />
                      <span>{course.duration}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Users className="h-4 w-4" />
                      <span>{course.students}</span>
                    </div>
                  </div>

                  {/* Course Features */}
                  <div className="mb-6">
                    <h4 className="text-sm font-semibold text-white mb-2 flex items-center">
                      <BookOpen className="h-4 w-4 mr-1" />
                      What You'll Learn
                    </h4>
                    <ul className="space-y-1">
                      {course.features.map((feature, index) => (
                        <li key={index} className="flex items-start space-x-2 text-sm text-gray-300">
                          <div className="w-1 h-1 bg-purple-400 rounded-full mt-2 flex-shrink-0"></div>
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Course Link */}
                  <a
                    href={course.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center w-full justify-center px-6 py-3 bg-purple-600 text-white font-semibold transition-all duration-300 hover:bg-purple-700 hover:shadow-lg hover:shadow-purple-500/25 group"
                  >
                    View Course
                    <ExternalLink className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Call to Action */}
        <div className="text-center mt-16 p-8 bg-purple-600/10 border border-purple-500/20 rounded-lg backdrop-blur-sm">
          <h2 className="text-3xl font-bold text-white mb-4">Ready to Start Learning?</h2>
          <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
            Invest in your future and join thousands of developers who have advanced their careers 
            through continuous learning. Your journey to becoming a skilled web developer starts now.
          </p>
          <a
            href="/apply"
            className="inline-flex items-center px-8 py-4 bg-purple-600 text-white font-semibold transition-all duration-300 hover:bg-purple-700 hover:shadow-lg hover:shadow-purple-500/25 group"
          >
            Apply for Training Program
            <ExternalLink className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
          </a>
        </div>
      </div>
    </div>
  );
};

export default Courses;