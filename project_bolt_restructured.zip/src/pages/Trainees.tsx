import React from 'react';
import { Github, Linkedin, ExternalLink } from 'lucide-react';

const Trainees: React.FC = () => {
  const trainees = [
    {
      id: 1,
      name: "Sarah Chen",
      role: "Full Stack Developer",
      image: "https://images.pexels.com/photos/3769021/pexels-photo-3769021.jpeg?auto=compress&cs=tinysrgb&w=400",
      bio: "Passionate about creating seamless user experiences with React and Node.js. Specializes in e-commerce solutions and has completed 5 major projects during her training.",
      skills: ["React", "Node.js", "MongoDB", "TypeScript"],
      github: "https://github.com",
      linkedin: "https://linkedin.com",
      portfolio: "https://portfolio.com"
    },
    {
      id: 2,
      name: "Marcus Thompson",
      role: "Frontend Specialist",
      image: "https://images.pexels.com/photos/3777931/pexels-photo-3777931.jpeg?auto=compress&cs=tinysrgb&w=400",
      bio: "UI/UX focused developer with a keen eye for design. Expert in modern CSS frameworks and animation libraries. Currently working on innovative web applications.",
      skills: ["Vue.js", "Tailwind CSS", "GSAP", "Figma"],
      github: "https://github.com",
      linkedin: "https://linkedin.com",
      portfolio: "https://portfolio.com"
    },
    {
      id: 3,
      name: "Emily Rodriguez",
      role: "Backend Developer",
      image: "https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=400",
      bio: "Database architect and API specialist. Experienced in microservices architecture and cloud deployment. Has built scalable solutions for multiple clients.",
      skills: ["Python", "Django", "PostgreSQL", "AWS"],
      github: "https://github.com",
      linkedin: "https://linkedin.com",
      portfolio: "https://portfolio.com"
    },
    {
      id: 4,
      name: "David Kim",
      role: "DevOps Engineer",
      image: "https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=400",
      bio: "Infrastructure automation expert with strong background in containerization and CI/CD pipelines. Passionate about optimizing development workflows.",
      skills: ["Docker", "Kubernetes", "Jenkins", "Terraform"],
      github: "https://github.com",
      linkedin: "https://linkedin.com",
      portfolio: "https://portfolio.com"
    },
    {
      id: 5,
      name: "Jessica Wang",
      role: "Mobile Developer",
      image: "https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg?auto=compress&cs=tinysrgb&w=400",
      bio: "Cross-platform mobile development specialist. Creates beautiful, performant mobile applications with React Native and Flutter. Published 3 apps in app stores.",
      skills: ["React Native", "Flutter", "Firebase", "Swift"],
      github: "https://github.com",
      linkedin: "https://linkedin.com",
      portfolio: "https://portfolio.com"
    },
    {
      id: 6,
      name: "Alex Johnson",
      role: "Data Engineer",
      image: "https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=400",
      bio: "Big data processing and analytics expert. Builds robust data pipelines and creates insightful visualizations. Experienced with machine learning integration.",
      skills: ["Python", "Apache Spark", "Kafka", "TensorFlow"],
      github: "https://github.com",
      linkedin: "https://linkedin.com",
      portfolio: "https://portfolio.com"
    }
  ];

  return (
    <div className="pt-24 pb-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl sm:text-5xl font-bold text-white mb-6">
            Meet Our
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-purple-600">
              Talented Trainees
            </span>
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Discover the brilliant minds shaping the future of web development. 
            Our trainees combine technical excellence with creative problem-solving.
          </p>
        </div>

        {/* Trainees Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {trainees.map((trainee) => (
            <div
              key={trainee.id}
              className="bg-gray-900/50 border border-purple-500/20 rounded-lg p-6 backdrop-blur-sm hover:bg-gray-900/70 hover:border-purple-500/40 transition-all duration-300 group"
            >
              {/* Profile Image */}
              <div className="relative mb-6">
                <img
                  src={trainee.image}
                  alt={trainee.name}
                  className="w-full h-48 object-cover rounded-lg"
                />
                <div className="absolute inset-0 bg-purple-600/20 rounded-lg group-hover:bg-purple-600/10 transition-colors"></div>
              </div>

              {/* Profile Info */}
              <div className="mb-4">
                <h3 className="text-xl font-bold text-white mb-1">{trainee.name}</h3>
                <p className="text-purple-300 font-medium">{trainee.role}</p>
              </div>

              {/* Bio */}
              <p className="text-gray-300 mb-4 leading-relaxed">{trainee.bio}</p>

              {/* Skills */}
              <div className="mb-6">
                <h4 className="text-sm font-semibold text-white mb-2">Skills</h4>
                <div className="flex flex-wrap gap-2">
                  {trainee.skills.map((skill, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-purple-600/20 text-purple-300 text-sm rounded-full border border-purple-500/30"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              {/* Links */}
              <div className="flex space-x-4">
                <a
                  href={trainee.github}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-purple-300 transition-colors"
                >
                  <Github className="h-5 w-5" />
                </a>
                <a
                  href={trainee.linkedin}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-purple-300 transition-colors"
                >
                  <Linkedin className="h-5 w-5" />
                </a>
                <a
                  href={trainee.portfolio}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-purple-300 transition-colors"
                >
                  <ExternalLink className="h-5 w-5" />
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16">
          <h2 className="text-3xl font-bold text-white mb-4">Want to Join Our Team?</h2>
          <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
            Start your journey with Hot Beans Web and become part of our talented community of developers.
          </p>
          <a
            href="/apply"
            className="inline-flex items-center px-8 py-4 bg-purple-600 text-white font-semibold transition-all duration-300 hover:bg-purple-700 hover:shadow-lg hover:shadow-purple-500/25"
          >
            Apply Now
          </a>
        </div>
      </div>
    </div>
  );
};

export default Trainees;