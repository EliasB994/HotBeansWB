import React from 'react';
import { MapPin, Clock, DollarSign, Users, ArrowRight } from 'lucide-react';

const Jobs: React.FC = () => {
  const jobs = [
    {
      id: 1,
      title: "Senior Full Stack Developer",
      company: "TechFlow Solutions",
      location: "London, UK",
      type: "Full-time",
      salary: "£70,000 - £90,000",
      team: "10-15 people",
      description: "Join our innovative team building next-generation web applications. We're looking for a senior developer to lead frontend initiatives and mentor junior developers.",
      requirements: [
        "5+ years experience with React and Node.js",
        "Strong understanding of TypeScript and modern JavaScript",
        "Experience with cloud platforms (AWS/Azure)",
        "Leadership and mentoring experience",
        "Excellent problem-solving skills"
      ],
      benefits: [
        "Competitive salary and equity package",
        "Flexible working arrangements",
        "Professional development budget",
        "Health and wellness benefits",
        "Modern office in central London"
      ]
    },
    {
      id: 2,
      title: "Frontend Developer",
      company: "Digital Innovations Ltd",
      location: "Manchester, UK",
      type: "Full-time",
      salary: "£45,000 - £60,000",
      team: "5-8 people",
      description: "Create beautiful, responsive user interfaces for our growing SaaS platform. Perfect opportunity for a mid-level developer looking to make a significant impact.",
      requirements: [
        "3+ years experience with React or Vue.js",
        "Proficiency in HTML5, CSS3, and JavaScript",
        "Experience with CSS frameworks (Tailwind, Bootstrap)",
        "Understanding of responsive design principles",
        "Git version control experience"
      ],
      benefits: [
        "Competitive salary with annual reviews",
        "Hybrid working model",
        "Learning and development opportunities",
        "Pension scheme",
        "Team building events and activities"
      ]
    },
    {
      id: 3,
      title: "Backend Developer",
      company: "CloudTech Enterprises",
      location: "Edinburgh, UK",
      type: "Full-time",
      salary: "£50,000 - £70,000",
      team: "8-12 people",
      description: "Build robust, scalable backend systems for our enterprise clients. Work with cutting-edge technologies in a collaborative environment.",
      requirements: [
        "4+ years experience with Python or Node.js",
        "Strong database design and optimization skills",
        "Experience with microservices architecture",
        "Knowledge of containerization (Docker/Kubernetes)",
        "API design and development experience"
      ],
      benefits: [
        "Competitive salary and performance bonuses",
        "Flexible working hours",
        "Private health insurance",
        "Training and certification support",
        "Relocation assistance available"
      ]
    },
    {
      id: 4,
      title: "Junior Web Developer",
      company: "StartupHub Co",
      location: "Birmingham, UK",
      type: "Full-time",
      salary: "£28,000 - £38,000",
      team: "3-5 people",
      description: "Perfect entry-level position for recent graduates or career changers. Join our fast-paced startup environment and grow your skills rapidly.",
      requirements: [
        "Basic knowledge of HTML, CSS, and JavaScript",
        "Familiarity with at least one modern framework",
        "Understanding of version control systems",
        "Strong willingness to learn and adapt",
        "Good communication and teamwork skills"
      ],
      benefits: [
        "Competitive junior salary",
        "Mentorship program",
        "Rapid career progression opportunities",
        "Flexible working arrangements",
        "Modern office space with amenities"
      ]
    },
    {
      id: 5,
      title: "DevOps Engineer",
      company: "InfraTech Solutions",
      location: "Bristol, UK",
      type: "Full-time",
      salary: "£55,000 - £75,000",
      team: "6-10 people",
      description: "Automate and optimize our development and deployment processes. Work with modern infrastructure tools and help shape our technical direction.",
      requirements: [
        "Experience with CI/CD pipelines",
        "Knowledge of containerization and orchestration",
        "Cloud platform experience (AWS/Azure/GCP)",
        "Infrastructure as Code experience",
        "Monitoring and logging tools expertise"
      ],
      benefits: [
        "Excellent salary and benefits package",
        "Remote-first culture",
        "Professional development budget",
        "Stock options",
        "Comprehensive health benefits"
      ]
    },
    {
      id: 6,
      title: "React Native Developer",
      company: "MobileFirst Labs",
      location: "Leeds, UK",
      type: "Contract",
      salary: "£400 - £600/day",
      team: "4-6 people",
      description: "Develop cross-platform mobile applications for our diverse client base. 6-month contract with potential for extension.",
      requirements: [
        "Strong React Native development experience",
        "iOS and Android deployment experience",
        "State management with Redux or Context API",
        "Integration with native modules",
        "App store optimization knowledge"
      ],
      benefits: [
        "Competitive day rate",
        "Flexible contract terms",
        "Opportunity for permanent role",
        "Interesting and varied projects",
        "Supportive team environment"
      ]
    }
  ];

  return (
    <div className="pt-24 pb-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl sm:text-5xl font-bold text-white mb-6">
            Discover Your Next
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-purple-600">
              Career Opportunity
            </span>
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Explore exciting positions with leading tech companies. From startups to enterprises, 
            find the perfect role to advance your career.
          </p>
        </div>

        {/* Jobs Grid */}
        <div className="space-y-8">
          {jobs.map((job) => (
            <div
              key={job.id}
              className="bg-gray-900/50 border border-purple-500/20 rounded-lg p-8 backdrop-blur-sm hover:bg-gray-900/70 hover:border-purple-500/40 transition-all duration-300 group"
            >
              {/* Job Header */}
              <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between mb-6">
                <div className="mb-4 lg:mb-0">
                  <h2 className="text-2xl font-bold text-white mb-2">{job.title}</h2>
                  <p className="text-purple-300 text-lg font-medium mb-2">{job.company}</p>
                  <div className="flex flex-wrap gap-4 text-gray-300">
                    <div className="flex items-center space-x-1">
                      <MapPin className="h-4 w-4 text-purple-400" />
                      <span>{job.location}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Clock className="h-4 w-4 text-purple-400" />
                      <span>{job.type}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <DollarSign className="h-4 w-4 text-purple-400" />
                      <span>{job.salary}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Users className="h-4 w-4 text-purple-400" />
                      <span>{job.team}</span>
                    </div>
                  </div>
                </div>
                <button className="flex items-center px-6 py-3 bg-purple-600 text-white font-semibold transition-all duration-300 hover:bg-purple-700 hover:shadow-lg hover:shadow-purple-500/25 group-hover:scale-105 lg:mt-0 mt-4">
                  Apply Now
                  <ArrowRight className="ml-2 h-4 w-4" />
                </button>
              </div>

              {/* Job Description */}
              <p className="text-gray-300 mb-6 leading-relaxed">{job.description}</p>

              {/* Requirements and Benefits */}
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-lg font-semibold text-white mb-4">Requirements</h3>
                  <ul className="space-y-2">
                    {job.requirements.map((requirement, index) => (
                      <li key={index} className="flex items-start space-x-3">
                        <div className="w-2 h-2 bg-purple-400 rounded-full mt-2 flex-shrink-0"></div>
                        <span className="text-gray-300">{requirement}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white mb-4">Benefits</h3>
                  <ul className="space-y-2">
                    {job.benefits.map((benefit, index) => (
                      <li key={index} className="flex items-start space-x-3">
                        <div className="w-2 h-2 bg-purple-400 rounded-full mt-2 flex-shrink-0"></div>
                        <span className="text-gray-300">{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16 p-8 bg-purple-600/10 border border-purple-500/20 rounded-lg backdrop-blur-sm">
          <h2 className="text-3xl font-bold text-white mb-4">Don't See the Perfect Role?</h2>
          <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
            We're always looking for talented developers. Submit your application and we'll keep you in mind for future opportunities.
          </p>
          <a
            href="/apply"
            className="inline-flex items-center px-8 py-4 bg-purple-600 text-white font-semibold transition-all duration-300 hover:bg-purple-700 hover:shadow-lg hover:shadow-purple-500/25 group"
          >
            Submit General Application
            <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
          </a>
        </div>
      </div>
    </div>
  );
};

export default Jobs;